<?php
/*
This file contains database config.phpuration assuming you are running mysql using user "root" and password ""
*/

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'if0_37886363');
define('DB_PASSWORD', '8laQFjlHK1Ut0P');
define('DB_NAME', 'if0_37886363_aman');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, if0_37886363DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
    Echo"Fail";
}

?>